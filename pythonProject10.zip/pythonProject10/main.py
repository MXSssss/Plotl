import plotly.graph_objects as go
import random

y = list(range(2001, 2021))

pd = {
    "київська область": [random.randint(1000000, 5000000) for _ in range(len(y))],
    "харківська область": [random.randint(1000000, 5000000) for _ in range(len(y))],
    "львівська область": [random.randint(1000000, 5000000) for _ in range(len(y))],
    "одеська область": [random.randint(1000000, 5000000) for _ in range(len(y))]
}

f = go.Figure()

for r, p in pd.items():
    f.add_trace(go.Scatter(
        x=y,
        y=p,
        mode='lines',
        name=r
    ))

f.update_layout(
    title_text="Зміна населення у різних регіонах України",
    xaxis_title="Рік",
    yaxis_title="Чисельність населення"
)

f.show()